document.addEventListener('DOMContentLoaded', function (){
    const tablaCamiones = document.getElementById('tablaCamiones');
    const botonCargar = document.getElementById('botonCargar');
    const inputPl = document.getElementById('inputPl');
    const botonBuscarPl = document.getElementById('botonBuscarPl');

    async function cargarDatos() {
        try {
            const response = await fetch('/camiones');
            const data = await response.json();

            // Limpiar la tabla antes de agregar nuevas filas
            tablaCamiones.innerHTML = '';

            // Agregar fila de títulos
            const titulos = document.createElement('tr');
            titulos.innerHTML = `
                <th>Clave</th>
                <th>Nombre</th>
                <th>Almacenaje</th>
                <th>Placa</th>
                <th>Marca</th>
            `;
            tablaCamiones.appendChild(titulos);

            // Agregar filas de datos
            data.forEach(camion => {
                const fila = document.createElement('tr');
                fila.innerHTML = `
                    <td>${camion.Idcamion}</td>
                    <td>${camion.Nombre}</td>
                    <td>${camion.Totalmacenaje}</td>
                    <td>${camion.Placas}</td>
                    <td>${camion.Marca}</td>
                `;
                tablaCamiones.appendChild(fila);
            });

            console.log('Datos cargados correctamente.');
        } catch (error) {
            console.error('Error al cargar los datos:', error);
        }
    }

    botonCargar.addEventListener('click', function () {
        cargarDatos();
    });

    botonBuscarPl.addEventListener('click', function () {
        const placa = inputPl.value.trim().toUpperCase();

        if (placa !== '') {
            buscarPorPl(placa);
        }
    });

    async function buscarPorPl(placa) {
        try {
            const response = await fetch(`/camiones/placa/${placa}`);
            const data = await response.json();

            // Limpiar la tabla antes de agregar nuevas filas
            tablaCamiones.innerHTML = '';

            // Agregar fila de títulos
            const titulos = document.createElement('tr');
            titulos.innerHTML = `
                <th>Clave</th>
                <th>Nombre</th>
                <th>Almacenaje</th>
                <th>Placa</th>
                <th>Marca</th>
            `;
            tablaCamiones.appendChild(titulos);

            // Agregar filas de datos
            data.forEach(camion => {
                const fila = document.createElement('tr');
                fila.innerHTML = `
                    <td>${camion.Idcamion}</td>
                    <td>${camion.Nombre}</td>
                    <td>${camion.Totalmacenaje}</td>
                    <td>${camion.Placas}</td>
                    <td>${camion.Marca}</td>
                `;
                tablaCamiones.appendChild(fila);
            });

            console.log('Búsqueda por placa completada.');
        } catch (error) {
            console.error('Error al buscar por placa:', error);
        }
    }
})