
const express = require('express');
const sqlite3 = require('sqlite3').verbose();

const app = express();
const port = 4000;

// const database = new sqlite3.Database('Refaccionaria.database');

// // Crear la tabla "Camion" si no existe
// database.run(`
//     CREATE TABLE IF NOT EXISTS Camion (
//         Idcamion INTEGER PRIMARY KEY,
//         Nombre TEXT,
//         Totalmacenaje REAL,
//         Placas TEXT,
//         Marca TEXT
//     )
// `, (err) => {
//     if (err) {
//         console.error(err.message);
//         throw err;
//     }

//     console.log('Tabla "Camion" creada exitosamente.');

//     // Insertar un ejemplo de dato
//     database.run(`
//         INSERT INTO Camion (Nombre, Totalmacenaje, Placas, Marca)
//         VALUES ('Camion01', 30000, 'JTP44', 'Ford')
//     `);

//     // Consultar todos los camiones
//     database.all('SELECT * FROM Camion', (err, rows) => {
//         if (err) {
//             console.error(err.message);
//             throw err;
//         }

//         // Imprimir resultados
//         console.log('Resultados de la consulta:');
//         rows.forEach(row => {
//             console.log(row);
//         });
//     });

//     // Cerrar la conexión después de realizar las operaciones
//     database.close();
// });

class ServiciosCamiones {
    constructor() {
        this.database = new sqlite3.Database('Refaccionaria.database', (err) => {
            if (err) {
                console.error(err.message);
                throw new Error('Error al abrir la base de datos');
            }
            console.log('Base de datos abierta correctamente.');
        });
    }

    getAllCamiones(callback) {
        this.database.all('SELECT * FROM Camion', (err, rows) => {
            if (err) {
                console.error(err.message);
                callback(err, null);
                return;
            }
            callback(null, rows);
        });
    }

    buscarPorPlaca(placa, callback) {
        this.database.all('SELECT * FROM Camion WHERE Placas = ?', [placa], (err, rows) => {
            if (err) {
                console.error(err.message);
                callback(err, null);
                return;
            }
            callback(null, rows);
        });
    }

    closeDatabase() {
        this.database.close((err) => {
            if (err) {
                console.error(err.message);
            } else {
                console.log('Conexión cerrada correctamente.');
            }
        });
    }
}

app.use(express.static('public'));

app.get('/camiones', (req, res) => {
    const camionService = new ServiciosCamiones();

    camionService.getAllCamiones((err, rows) => {
        if (err) {
            res.status(500).json({ error: 'Error interno del servidor' });
            return;
        }

        res.json(rows);
        camionService.closeDatabase();
    });
});

app.get('/camiones/placa/:placa', (req, res) => {
    const placa = req.params.placa;

    const camionService = new ServiciosCamiones();

    camionService.buscarPorPlaca(placa, (err, rows) => {
        if (err) {
            res.status(500).json({ error: 'Error interno del servidor' });
            return;
        }

        res.json(rows);
        camionService.closeDatabase();
    });
});

app.listen(port, () => {
    console.log(`Servidor web escuchando en http://localhost:${port}`);
});